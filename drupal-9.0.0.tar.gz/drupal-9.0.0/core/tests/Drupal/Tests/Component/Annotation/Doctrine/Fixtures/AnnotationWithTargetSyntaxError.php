<?php
// @codingStandardsIgnoreFile

namespace Drupal\Tests\Component\Annotation\Doctrine\Fixtures;

/**
 * @Annotation
 * @Target(@)
 */
final class AnnotationWithTargetSyntaxError
{
}
