<?php
// @codingStandardsIgnoreFile

namespace Drupal\Tests\Component\Annotation\Doctrine\Fixtures;

interface IntefaceWithConstants
{

    const SOME_VALUE = 'IntefaceWithConstants.SOME_VALUE';
    const SOME_KEY   = 'IntefaceWithConstants.SOME_KEY';
}
