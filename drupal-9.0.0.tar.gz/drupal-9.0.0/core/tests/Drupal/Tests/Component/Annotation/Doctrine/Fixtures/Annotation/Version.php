<?php
// @codingStandardsIgnoreFile

namespace Drupal\Tests\Component\Annotation\Doctrine\Fixtures\Annotation;

/**
 * @Annotation
 * @Target("PROPERTY")
 */
final class Version
{
}
