<?php
// @codingStandardsIgnoreFile

namespace Drupal\Tests\Component\Annotation\Doctrine\Fixtures\Annotation;

/**
 * @Annotation
 */
class Autoload
{
}
