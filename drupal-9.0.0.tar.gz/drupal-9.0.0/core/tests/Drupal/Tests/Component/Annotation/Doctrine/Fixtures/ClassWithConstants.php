<?php
// @codingStandardsIgnoreFile

namespace Drupal\Tests\Component\Annotation\Doctrine\Fixtures;

class ClassWithConstants
{
    const SOME_VALUE  = 'ClassWithConstants.SOME_VALUE';
    const SOME_KEY    = 'ClassWithConstants.SOME_KEY';
    const OTHER_KEY_  = 'ClassWithConstants.OTHER_KEY_';
    const OTHER_KEY_2 = 'ClassWithConstants.OTHER_KEY_2';
}
