<?php
// @codingStandardsIgnoreFile

// Some class named Entity in the global namespace
/**
 * This class is a near-copy of
 * tests/Doctrine/Tests/Common/Annotations/Ticket/DCOM58Entity.php, which is
 * part of the Doctrine project: <http://www.doctrine-project.org>.  It was
 * copied from version 1.2.7.
 *
 * @Annotation
 */
class Entity
{
}
