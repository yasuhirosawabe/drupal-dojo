<?php

namespace Drupal\Tests\Component\Plugin\Fixtures\vegetable;

/**
 * @Plugin(
 *   id = "broccoli",
 *   label = "Broccoli",
 *   color = "green"
 * )
 */
class Broccoli {}
