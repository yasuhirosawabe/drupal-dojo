<?php

namespace Drupal\Tests\Component\Plugin\Fixtures\vegetable;

/**
 * @Plugin(
 *   id = "corn",
 *   label = "Corn",
 *   color = "yellow"
 * )
 */
class Corn implements VegetableInterface {}
