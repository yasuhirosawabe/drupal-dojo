<?php

namespace Drupal\Tests\Component\Plugin\Fixtures\vegetable;

/**
 * Provides an interface for test plugins.
 */
interface VegetableInterface {}
