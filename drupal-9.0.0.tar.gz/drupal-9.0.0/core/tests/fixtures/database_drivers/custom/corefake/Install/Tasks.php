<?php

namespace Drupal\Driver\Database\corefake\Install;

use Drupal\Core\Database\Driver\corefake\Install\Tasks as BaseInstallTasks;

class Tasks extends BaseInstallTasks {

}
