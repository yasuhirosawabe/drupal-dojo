<?php

namespace Drupal\Driver\Database\corefake;

use Drupal\Core\Database\Driver\corefake\Connection as CoreFakeConnection;

class Connection extends CoreFakeConnection {}
