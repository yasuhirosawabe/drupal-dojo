<?php

namespace Drupal\corefake\Driver\Database\corefakeWithAllCustomClasses;

use Drupal\Core\Database\Query\Condition as QueryCondition;

/**
 * CorefakeWithAllCustomClasses implementation of \Drupal\Core\Database\Condition.
 */
class Condition extends QueryCondition {

}
