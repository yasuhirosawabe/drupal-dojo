<?php

namespace Drupal\corefake\Driver\Database\corefakeWithAllCustomClasses;

use Drupal\Core\Database\Query\Merge as QueryMerge;

/**
 * CorefakeWithAllCustomClasses implementation of \Drupal\Core\Database\Merge.
 */
class Merge extends QueryMerge {

}
