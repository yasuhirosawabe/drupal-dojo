<?php

namespace Drupal\corefake\Driver\Database\corefakeWithAllCustomClasses;

use Drupal\Core\Database\Query\Insert as QueryInsert;

/**
 * CorefakeWithAllCustomClasses implementation of \Drupal\Core\Database\Insert.
 */
class Insert extends QueryInsert {

}
