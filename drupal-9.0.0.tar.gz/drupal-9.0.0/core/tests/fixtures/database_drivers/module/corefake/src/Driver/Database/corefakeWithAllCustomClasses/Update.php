<?php

namespace Drupal\corefake\Driver\Database\corefakeWithAllCustomClasses;

use Drupal\Core\Database\Query\Update as QueryUpdate;

/**
 * CorefakeWithAllCustomClasses implementation of \Drupal\Core\Database\Update.
 */
class Update extends QueryUpdate {

}
