<?php

namespace Drupal\corefake\Driver\Database\corefakeWithAllCustomClasses;

use Drupal\Core\Database\Query\Truncate as QueryTruncate;

/**
 * CorefakeWithAllCustomClasses implementation of \Drupal\Core\Database\Truncate.
 */
class Truncate extends QueryTruncate {

}
