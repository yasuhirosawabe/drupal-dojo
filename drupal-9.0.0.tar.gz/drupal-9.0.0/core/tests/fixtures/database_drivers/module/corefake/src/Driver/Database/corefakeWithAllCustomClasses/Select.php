<?php

namespace Drupal\corefake\Driver\Database\corefakeWithAllCustomClasses;

use Drupal\Core\Database\Query\Select as QuerySelect;

/**
 * CorefakeWithAllCustomClasses implementation of \Drupal\Core\Database\Select.
 */
class Select extends QuerySelect {

}
