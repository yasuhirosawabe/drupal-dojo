<?php

namespace Drupal\corefake\Driver\Database\corefakeWithAllCustomClasses;

use Drupal\Core\Database\Query\Delete as QueryDelete;

/**
 * CorefakeWithAllCustomClasses implementation of \Drupal\Core\Database\Delete.
 */
class Delete extends QueryDelete {

}
