<?php

namespace Drupal\corefake\Driver\Database\corefakeWithAllCustomClasses;

use Drupal\Core\Database\Transaction as DatabaseTransaction;

/**
 * CorefakeWithAllCustomClasses implementation of \Drupal\Core\Database\Transaction.
 */
class Transaction extends DatabaseTransaction {

}
