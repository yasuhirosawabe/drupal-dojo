<?php
// @codingStandardsIgnoreFile
print 'SimpleTest PHP was executed!';
