<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x10 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x20 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x30 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x40 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x50 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL,
  0x60 => NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x70 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x80 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x90 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0xA0 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0xB0 => NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL,
  0xC0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0xD0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0xE0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0xF0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
];
